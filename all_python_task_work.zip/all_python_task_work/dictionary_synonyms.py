dict1={}
class syno:
	def __init__(self,dict1):
		self.dict1={'order':'rule','beauty':'glamor','exist':'present','locate':'detect','lock':'bond'}
		print "dict contains\n",self.dict1
		
	
	def adddict(self): 
		key=raw_input("enter the word to get synonyms\n")
		if key in self.dict1:
			print "-------------"
			print "synonyms of the %s is ------ " % key,self.dict1[key]
		else:
			print "no word found\n"
			print "enter ur synonyms to stored in dictionary\n"
			value=raw_input("enter the value of dictionary\n")
			self.dict1[key]=value
			print self.dict1
			obj.adddict()

obj=syno(dict1)
obj.adddict()
