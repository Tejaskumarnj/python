dict1={}
top=-1

stack_size=input("enter the size of stack\n")

#-------------------Push stack element------------------
if top==(stack_size-1):
	print "stack is full\n"
	
else :
	for i in range(stack_size):
		data=input("enter the element to push\t")
		dict1[i]=data
		liskey=dict1.keys()
		lisval=dict1.values()
		top=liskey[i]
		
	print "\n"
	print "element in stack after inserted"
	x=dict1.values()
	for i in x:
		print i		
	

#-------------------Pop stack element-------------------------	

if top==-1:
	print "stack underflow"
else :
	
	print "poped element from the stack\n",dict1[top]
	del dict1[top]
		

#-------------------displaying element------------------------
print "\n"
print "displaying of stack elements"
x=dict1.values()
for i in x:
	print i	
print "--------------------------"
#--------------------queue operation-----------------------

front=-1
rear=-1
dict2={}

queue_size=input("enter the size of queue\n")

if front==rear:
	print "empty queue\n"

if rear==(queue_size-1):
	print "queue is full\n"
else:	
	if front==-1:
		front=0
		for i in range(queue_size):
			data=input("enter the element to insert\t")
			rear=rear+1
			dict2[rear]=data
			liskey=dict2.keys()	
			lisval=dict2.values()
		print "\n"	
		print "data in queue after inserted"
		x=dict2.values()
		for i in x:
			print i	
		print "\n"
#------------------------delete queue--------------------	
		
if (front==-1)|(front>rear):
	print "queue underflow\n"
else:
	
	print "element deleted from queue \n",dict2[front]
	del dict2[front]
	front=front+1
print "\n"
#-------------------display of queue---------------

print "displaying element in the queue \n"
x=dict2.values()
for i in x:
	print i







