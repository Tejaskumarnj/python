#day 5 task given in class
#creating a class and defination
#performs addition,subtratcion,multipication,square root
#calling by object

class cn:

	        def __init__(self,x):
		       self.x=x
	     
		def __str__(self):
	     		return str(self.x)

	   	def __del__(self):
	     		print "obj removed"
	
		def sqr(self):
			return self.x**2
	
		def __add__(self,other1):
			return self.x+other1.x

		def __sub__(self,other):
	     		return self.x-other.x

	  	def __mul__(self,other):
	    		 return self.x*other.x
		
		
	   
		 
a=cn(100)
b=cn(200) 
print a 
print b
print a.sqr()
print b.sqr()
print a+b
print a-b
print a*b
	



