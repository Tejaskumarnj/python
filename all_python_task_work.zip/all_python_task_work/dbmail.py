import MySQLdb
import smtplib
import getpass


localhost="localhost"
user="root"
password="PASSWORD"
database="employee"

con=MySQLdb.connect(localhost,user,password,database)

cursor=con.cursor()


cursor.execute("select * from emp;")
con.commit()
data1=cursor.fetchall()


sr=''
for row in data2:
	line="%s\t %s\t %s"%(row[0],row[1],row[2])
	sr=sr+line+'\n'
print sr


host="smtp.gmail.com"
port=587
server=smtplib.SMTP(host,port)
server.ehlo()
server.starttls()
server.ehlo
username=raw_input("gmail\n")
password=getpass.getpass()
server.login(username,password)
to=raw_input("to\n")
sub=raw_input("sub\n")
mes=data
message="subject: %s\n%s\n%s"%(sub,sr1,sr)
server.sendmail(username,to,message)
con.close()





