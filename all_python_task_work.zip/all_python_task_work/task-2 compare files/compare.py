'''Write a python script to compare the attached two files and find out status ok and FAIL

    Total number of lines starting with 'tempest' in first  file 
    Total number of lines starting with 'tempest' in second  file 
    Total number of lines 'tempest' to '...' matching status same  ( both are 'ok' or both are 'FAIL' )
    Total number of lines 'tempest' to '...' matching status differs  ( one file have 'ok' and another has 'FAIL' )
    Total number of lines 'tempest' to '...' matching status may be anything ( the status is neither 'ok' not 'FAIL')
    Total number of lines 'tempest' to '...' available in first not in second
    Total number of lines 'tempest' to '...' available in second not in first
    Create a file which has lines 'tempest' to '...' matching status same  ( both are 'ok' or both are 'FAIL' )
    Create a file which has lines 'tempest' to '...' matching status differs  ( one file have 'ok' and another has 'FAIL' )
    Create a file which has lines 'tempest' to '...' available in first not in second
    Create a file which has lines 'tempest' to '...' available in second not in first
    Create a file which has lines 'tempest' to '...' matching status may be anything ( the status is neither 'ok' not 'FAIL')'''


import re
import time
import sys


src1=sys.argv[1]
dst1=sys.argv[2]

class compare:
	def __init__(self,src1,dsc1):
			self.src=open(src1)
			self.dst=open(dst1)
			self.f1=open('file1.txt','w+')
			self.f2=open('file2.txt','w+')
			self.f3=open('file3.txt','w+')
			self.f4=open('file4.txt','w+')
			self.f5=open('file5.txt','w+')
			self.dict1={}
			self.list1=[]
			self.dict2={}
			self.list2=[]
			


#------------------------------>source file------------------------->
	def compare_twofile(self):

		

		try:		
			for line in self.src:
				reg1=re.search(r'(tempest.*)',line,re.I)
				if reg1:
					#print reg1.group()
					reg1=str(reg1.group())
					source=reg1.split(' ... ') ##spliting the string in file
					stemp=source[0]
					sval=source[1]
					sval=sval.strip('\r')			
					self.dict1[stemp]=sval
					#print dict1
					s=str(stemp)+' ... '+str(sval)
					self.list1.append(s)
			

	
		except IndexError:
				print "full source file extracted"
				#time.sleep(6)
				
	

		#----------------------------->distination file-------------------------->


		

		try:
			for line in self.dst:
				reg2=re.search(r'(tempest.[a-zA-Z](.*))',line,re.I)
				if reg2:
					#print reg2.group()
					reg2=str(reg2.group()) 
					dest=reg2.split(' ... ') #spliting the string in file
					dtemp=dest[0]
					dval=dest[1]
					self.dict2[dtemp]=dval
					s1=str(dtemp)+' ... '+str(dval)  #
					self.list2.append(s1)
					#break
			

		except IndexError:

				print " destination file extracted"



		#---------------------------------------**********total line of 1st and 2nd file****************--------------------------


		print "Total number of lines starting with 'tempest' in first  file  %d "%len(self.dict1)
		print "Total number of lines starting with 'tempest' in second  file  %d" % len(self.dict2)



		d1set=set(self.list1)
		d2set=set(self.list2)



		match=d1set.intersection(d2set)
		print "Total number of lines 'tempest' to '...' matching status same %d" % len(match)   #1663


		for i in match:
			self.f1.writelines(i+'\n')	


	
		#-----------------------------------------**********maching differ***************------------------------------------------
		count1=0
		for dict1key in self.dict1:
			for dict2key in self.dict2:
				 if(dict1key==dict2key):
					if(self.dict1[dict1key]!=self.dict2[dict2key]):
						count1=count1+1
				
						self.f2.writelines(dict1key+'\n')
		print " Total number of lines 'tempest' to '...' matching status differs   %d " % count1    #221



		#------------------------------------------*********status neither ok nor FAIL*****************--------------------------------------
		count2=0
		count3=0
		for line1 in self.dict1:
			for line2 in self.dict2:
				if(line1==line2):
					if(((self.dict1[line1]!='ok')&(self.dict1[line1]!='FAIL'))&((self.dict2[line2]!='ok')&(self.dict2[line2]!='FAIL'))):
						count2=count2+1
						self.f3.writelines(line1+'\n')                   #87
				

		print  "Total number of lines 'tempest' to '...' matching status may be anything the status is neither 'ok' not FAIL   %d" % count2

		#-------------------------------------------***********not in second****************-------------------------------------

		key1=self.dict1.keys()
		key2=self.dict2.keys()


		key1=set(key1)
		key2=set(key2)


		notinsecond=key1.difference(key2)

		print "Total number of lines 'tempest' to '...' available in first not in second  %d" % len(notinsecond)   #576

		for i in notinsecond:
			self.f4.writelines(i+'\n')

		#--------------------------------------------************not in 1st file****************---------------------------------------------



		notinfirst=key2.difference(key1)

		print "Total number of lines 'tempest' to '...' available in second not in first  %d" % len(notinfirst)    #175

		for i in notinfirst:
			self.f5.writelines(i+'\n')



a=compare(src1,dst1)
a.compare_twofile()









